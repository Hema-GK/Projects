function fetchData(callback) {
   console.log("Fetching data...");
   setTimeout(() => {
       console.log("Data fetched.");
       callback("Sample Data");
   }, 2000);
}

function processData() {
   console.log("Processing: " );
}

fetchData(processData);

// Output:
// Fetching data...
// Data fetched.
// Processing: Sample Data
